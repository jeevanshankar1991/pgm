README.txt

How to run the code 

$ python learning.py trainFile testFile


Note :

1. For 3rd question, open learning.py and in main function, uncomment
for required CPT table

2. For 5th, 6th question, just run '$ python learning.py trainFile testFile' 

3. For the 7th questions, run '$ python learning_modelling.py trainFile testFile'
